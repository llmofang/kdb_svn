/*

  ECHOSERV.C
  ==========
  Simple TCP/IP echo server.
  WooiKent Lee

*/


#include <arpa/inet.h>        /*  inet (3) funtions         */
#include <unistd.h>           /*  misc. UNIX functions      */
#include <string.h>
#include <time.h>

#include <stdlib.h>
#include <stdio.h>


/*  Global constants  */

#define ECHO_PORT          (2002)
#define MAX_LINE           (1000)
#define LISTENQ		   (1024)

/* Define a function */

void gen_random(char *s){
	
	int i;
	
	static const char alphanum[] = 
	"0123456789"
	"ABCDEFGHIJKLMNOPQRSTUVWXYZ"
	"abcdefghijklmnopqrstuvwxyz";
	
	/* Create random string between length 1 to 10 (rand()%10+1)*/
	for (i = 0 ; i < rand()%10+1 ; ++i) {
		s[i] = alphanum[rand() % (sizeof(alphanum) - 1)];
	}
	
	s[i] = 0;
}

/* main */

int main(int argc, char *argv[]) {
    int       list_s;                /*  listening socket          */
    int       conn_s;                /*  connection socket         */
    short int port;                  /*  port number               */
    struct    sockaddr_in servaddr;  /*  socket address structure  */
    char     *endptr;                /*  for strtol()              */
    char      buffer[MAX_LINE];     /*  character buffer	   */
    char      bufferR[MAX_LINE];
    time_t    now;
 
    /*  Get port number from the command line, and
        set to default port if no arguments were supplied  */

    if ( argc == 2 ) {
	port = strtol(argv[1], &endptr, 0);
	if ( *endptr ) {
	    fprintf(stderr, "ECHOSERV: Invalid port number.\n");
	    exit(EXIT_FAILURE);
	}
    }
    else if ( argc < 2 ) {
	port = ECHO_PORT;
    }
    else {
	fprintf(stderr, "ECHOSERV: Invalid arguments.\n");
	exit(EXIT_FAILURE);
    }
	
    /*  Create the listening socket  */

    if ( (list_s = socket(AF_INET, SOCK_STREAM, 0)) < 0 ) {
	fprintf(stderr, "ECHOSERV: Error creating listening socket.\n");
	exit(EXIT_FAILURE);
    }


    /*  Set all bytes in socket address structure to
        zero, and fill in the relevant data members   */

    memset(&servaddr, 0, sizeof(servaddr));
    servaddr.sin_family      = AF_INET;
    servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
    servaddr.sin_port        = htons(port);


    /*  Bind our socket addresss to the 
	listening socket, and call listen()  */

    if ( bind(list_s, (struct sockaddr *) &servaddr, sizeof(servaddr)) < 0 ) {
	fprintf(stderr, "ECHOSERV: Error calling bind()\n");
	exit(EXIT_FAILURE);
    }

    if ( listen(list_s, LISTENQ) < 0 ) {
	fprintf(stderr, "ECHOSERV: Error calling listen()\n");
	exit(EXIT_FAILURE);
    }

    while (1) {

      /*  Wait for a connection, then accept() it  */

      if ( (conn_s = accept(list_s, NULL, NULL) ) < 0 ) {
          fprintf(stderr, "ECHOSERV: Error calling accept()\n");
          exit(EXIT_FAILURE);
      }
      
      time(&now);
      printf("%s: Connection opened \n",ctime(&now));

      /* Send a reponse to the connected client every second */

      while (2) { 

	/*  Put the random string into the message structure  */
	gen_random(buffer);
	sprintf(bufferR,"%i%s\n",strlen(buffer),buffer);
	
	/* Send the response to the client */
	if(write(conn_s, bufferR, strlen(bufferR)) < 0) {
		perror("sendto");
		break;
	}
	else {
	/* Print the response */
	time(&now);
	printf("%s: sent %s ",ctime(&now),bufferR);
	sleep(1);
	}

      }

      /*  Close the connected socket  */

      if ( close(conn_s) < 0 ) {
          fprintf(stderr, "ECHOSERV: Error calling close()\n");
          exit(EXIT_FAILURE);
      }

    }

    return EXIT_SUCCESS;
}
