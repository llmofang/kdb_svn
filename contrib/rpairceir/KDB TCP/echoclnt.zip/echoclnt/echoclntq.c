/*

  ECHOCLNT.C
  ==========
  Simple TCP/IP echo client.
  WooiKent Lee

*/

#include <arpa/inet.h>        /*  inet (3) funtions         */

#include "k.h"		      /*  Interface with Q	    */

#include <string.h>

/*  Global constants  */
#define MAX_LINE           (1000)

/* Declare a function */
K rtnmsg();
K disconn();
void onerror( char *message);

/* Define global */
struct	sockaddr_in servaddr;  /*  socket address structure  */
int	conn_s;		       /*  handle  */
char	bufferR[MAX_LINE];
int     PORT = 0;
char*   IPADD = NULL;
char*   CALLBACK = NULL;

/* connction routine  */
K conn(K ipaddressq , K portq, K callback ){

    /*  Inspect each K object for type */

    if ( -6 != portq->t ){krr("porttype");return (K)0;}
    PORT = portq->i;
    if ( -11 != ipaddressq->t ){krr("iptype");return (K)0;}
    IPADD = ipaddressq->s;
    if ( -11 != callback->t ){krr("cbtype");return (K)0;}
    CALLBACK = callback->s;

    /*  Create the listening socket  */

    if ( (conn_s = socket(AF_INET, SOCK_STREAM, 0)) < 0 ) {
	krr("nosocket");
	return (K)0;
    }

    /*  Set all bytes in socket address structure to
        zero, and fill in the relevant data members   */

    memset(&servaddr, 0, sizeof(servaddr));
    servaddr.sin_family      = AF_INET;
    servaddr.sin_port        = htons(PORT);

    /*  Set the remote IP address  */

    if ( inet_aton(IPADD, &servaddr.sin_addr) <= 0 ) {
	krr("ipaddr");
	return (K)0;
    }
    
    /*  connect() to the remote echo server  */

    if ( connect(conn_s, (struct sockaddr *) &servaddr, sizeof(servaddr) ) < 0 ) {
   	krr("noconnect");
   	return (K)0; 
    }

    /*  Retrieve response everytime the server sends an update */

    sd1(conn_s,rtnmsg);    

    return (K)0;
    
}

/* A function to retrive response from server */
K rtnmsg(){
      
	/* Put the first byte into c to let us know how what length the message is */
	char c[1];
	if ( read(conn_s, c, 1) <= 0 ){
		onerror("nobyte");
		sd0(conn_s);
		close(conn_s);
		return (K)0;
	}
        int len = atoi(c);

	/* Read the message into bufferR */
	if( read(conn_s, &bufferR, len) <= 0 ){
		onerror("nomsg");
		sd0(conn_s);
		close(conn_s);
		return (K)0;
	}
        
	/* Read the end of message return an error if message invalid */
	char suc[1];
	read(conn_s, suc, 1);
	if ( *suc != '\n' ){
		onerror("msgntcmplt");
		sd0(conn_s);
		close(conn_s);
		return (K)0;
	}

 	/* Send the response to Q */
        k(0,CALLBACK,kpn(bufferR,len),(K)0);
	
    return (K)0;

}

/*  Close the connection to TCP server  */
K disconn(K x){

    sd0(conn_s);
    close(conn_s);
    return (K)0;

}

/*  Send an error message to q session  */
void onerror( char *message)
{

	k(0,"oneerror",kpn(message,strlen(message)),(K)0);

	return;

}
