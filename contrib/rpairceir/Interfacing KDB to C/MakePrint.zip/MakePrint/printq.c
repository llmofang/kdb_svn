#define KXVER 2		//for using the correct k structure
#include"k.h"		//for interfacing with kdb+
#include<stdio.h>
#include<stdlib.h>
#include<time.h>	//for time format
#include<math.h>	//for round

/*  Declare function  */
K printq(K x);
K printdic(K x);
K printtab(K x);
K printlist(K x);
K printatom(K x);

/*  Decide which function to use  */
K printq(K x){

	//Check for atom
	if(x->t<0){printatom(x);printf("\n");}

	//Check for list
	else if(x->t>=0 && x->t<=19){printlist(x);}

	//Check for table
	else if(x->t==98){printtab(x);}

	//Check for dictionary
	else if(x->t==99){printdic(x);}

	else{printf("cannot support %d type\n",x->t);}

	return (K)0;

}

/*  Print a dictionary in Q  */
K printdic(K x){

	/*  Get the type of the object  */
	int typeq = x->t;
	int row;
	
	K keyName = kK(x)[0];
	K keyData = kK(x)[1];

	int nName = keyName->n;

	printf("Dictionary(%d)\n",typeq);

	for(row=0;row<nName;row++){

		printf("%s\t| ",kS(keyName)[row]);
		
		if(kK(keyData)[row]->n>1){printlist(kK(keyData)[row]);}
		else{printatom(kK(keyData)[row]);printf("\n");}

	}

	return (K)0;

}

/*  Print a table in Q  */
K printtab(K x){

	/*  Get the type of the object  */
	int typeq = x->t;
	int row,col;

	K flip=ktd(x);

	K colName = kK(flip->k)[0];
	K colData = kK(flip->k)[1];

	int nCols = colName->n;
	int nRows = kK(colData)[0]->n;

	printf("Table(%d)\n",typeq);

	for(row=0;row<nRows;row++){

		//Print the column names
		if(0==row){

			for(col=0;col<nCols;col++){

				if(col>0)printf("\t");
				printf("%s",kS(colName)[col]);

			}
			printf("\n");

		}
		//Print the data
		for(col=0;col<nCols;col++){
			
			K list = kK(colData)[col];
			if(col>0)printf("\t");
			switch(list->t){

				//mixed
				case(0):{	if(kK(list)[row]->t<0){printatom(kK(list)[row]);}
						else{printf("cannot support list in mixed list\n");return(K)0;}
						}break;	

				//boolean
				case(1):{	K obj = kb(kG(list)[row]);
						printatom(obj);
						}break;
							
				//byte
				case(4):{       K obj = kg(kG(list)[row]);
                       				printatom(obj);
                      				}break;

				//short
	                        case(5):{       K obj = kh(kH(list)[row]);
              				        printatom(obj);
                      				}break;

				//int
	                        case(6):{       K obj = ki(kI(list)[row]);
               				        printatom(obj);
                       				}break;
  
				//long
				case(7):{       K obj = kj(kJ(list)[row]);
						printatom(obj);
                      				}break;

				//real
	                        case(8):{       K obj = ke(kE(list)[row]);
               					printatom(obj);
                       				}break;

				//float
      				case(9):{       K obj = kf(kF(list)[row]);
                       				printatom(obj);
                      				}break;

				//char
      				case(10):{      K obj = kc(kC(list)[row]);
                      				printatom(obj);
                      				}break;

				//symbol
                       		case(11):{      K obj = ks(kS(list)[row]);
                      				printatom(obj);
                      				}break;

				//timestamp
        			case(12):{      K obj = ktj(-KP,kJ(list)[row]);
                      				printatom(obj);
                      				}break;

				//month
       				case(13):{      K obj = ka(-KM);
                      				obj->i = kI(list)[row];
	              				printatom(obj);
                     				}break;

				//date
	                        case(14):{      K obj = kd(kI(list)[row]);
	              				printatom(obj);
                    				}break;

				//datetime
       				case(15):{      K obj = kz(kF(list)[row]);
                				printatom(obj);
                  				}break;

				//timespan
				case(16):{      K obj = ktj(-KN,kJ(list)[row]);
	              				printatom(obj);
                  				}break;

				//minute
 				case(17):{      K obj = ka(-KU);
                  				obj->i = kI(list)[row];
                    				printatom(obj);
                  				}break;

				//second
  				case(18):{      K obj = ka(-KV);
                				obj->i = kI(list)[row];
                   				printatom(obj);
                  				}break;

				//time
   				case(19):{      K obj = kt(kI(list)[row]);
                 				printatom(obj);
                  				}break;

				default:{	printf("cannot support %d type",list->t);
						return (K)0;
						}break;
			}
		}
		printf("\n");
			
	}

	return (K)0;

}

/*  Print a list in Q  */
K printlist(K x){

	/*  Get the type of the object  */
	int typeq = x->t;
	int nData = x->n;
	int i;

	for(i=0;i<nData;i++){

		if(i>0)printf("\t");
		switch(typeq){

			//mixed		i.e. 1 1b 0x01
			case(0):{	if(kK(x)[i]->t<0){printatom(kK(x)[i]);}
					else{printf("cannot support list in mixed list\n");return(K)0;}
					}break;	
			
			//boolean       i.e. 01b
			case(1):{	K obj = kb(kG(x)[i]);
					printatom(obj);
					}break;

			//byte		i.e. 0x0204
			case(4):{	K obj = kg(kG(x)[i]);
					printatom(obj);
					}break;

			//short		i.e. 1 2h
			case(5):{	K obj = kh(kH(x)[i]);
					printatom(obj);
					}break;

			//int		i.e. 1 2
			case(6):{	K obj = ki(kI(x)[i]);
					printatom(obj);
					}break;

			//long		i.e. 1 2j
			case(7):{	K obj = kj(kJ(x)[i]);
					printatom(obj);
					}break;

			//real		i.e. 1.0 2.0e
			case(8):{	K obj = ke(kE(x)[i]);
					printatom(obj);
					}break;

			//float		i.e. 1.0 2.0
			case(9):{	K obj = kf(kF(x)[i]);
					printatom(obj);
					}break;

			//char		i.e. "ab"
			case(10):{	K obj = kc(kC(x)[i]);
					printatom(obj);
					}break;

			//symbol	i.e. `a`b
			case(11):{	K obj = ks(kS(x)[i]);
					printatom(obj);
					}break;

			//timestamp	i.e. dateDtimespan x2
			case(12):{	K obj = ktj(-KP,kJ(x)[i]);
					printatom(obj);
					}break;

			//month		i.e. 2010.01 2010.02
			case(13):{	K obj = ka(-KM);
					obj->i = kI(x)[i];
					printatom(obj);
					}break;

			//date		i.e. 2010.01.01 2010.01.02
			case(14):{	K obj = kd(kI(x)[i]);
					printatom(obj);
					}break;
		
			//datetime	i.e. 2010.01.01T12:12:12.000 x2
			case(15):{	K obj = kz(kF(x)[i]);
					printatom(obj);
					}break;

			//timespan	i.e. 0D00:00:00.000000000 x2
			case(16):{	K obj = ktj(-KN,kJ(x)[i]);
					printatom(obj);
					}break;

			//minute	i.e. 00:00 00:01
			case(17):{	K obj = ka(-KU);
					obj->i = kI(x)[i];
					printatom(obj);
					}break;

			//second	i.e. 00:00:00 00:00:01
			case(18):{	K obj = ka(-KV);
					obj->i = kI(x)[i];
					printatom(obj);
					}break;

			//time		i.e. 00:00:00.111 00:00:00.222
			case(19):{	K obj = kt(kI(x)[i]);
					printatom(obj);
					}break;

			default:{	printf("cannot support %d type",x->t);
					return (K)0;
					}break;
	
		}

	}
	printf("\n");

	return (K)0;

}

/*  Print an atom  */
K printatom(K x){
	
	/*  Get the type of the object  */
	int typeq = x->t;

	switch(typeq){

		//boolean       i.e. 0b
		case(-1):{	printf("Boolean(%d) %d",typeq,x->g);
				}break;

		//byte          i.e. 0x00
		case(-4):{	printf("Byte(%d) %02x",typeq,x->g);
				}break;

		//short         i.e. 0h
		case(-5):{	printf("Short(%d) %d",typeq,x->h);
				}break;

		//int           i.e. 0
		case(-6):{	printf("Int(%d) %d",typeq,x->i);
				}break;

		//long          i.e. 0j
		case(-7):{	printf("Long(%d) %lld",typeq,x->j);
				}break;

		//real          i.e. 0e
		case(-8):{	printf("Real(%d) %f",typeq,x->e);
				}break;

		//float         i.e. 0.0
		case(-9):{	printf("Float(%d) %f",typeq,x->f);
				}break;

		//char          i.e. "a"
		case(-10):{	printf("Char(%d) %c",typeq,x->i);
				}break;
		
		//symbol        i.e. `a
		case(-11):{	printf("Symbol(%d) %s",typeq,x->s);
				}break;

		//timestamp     i.e. dateDtimespan
		case(-12):{	time_t timval=((x->j)/8.64e13+10957)*8.64e4;
				struct tm *timinfo;
				timinfo=localtime(&timval);
				printf("Timestamp(%d) %04d.%02d.%02dD%02d:%02d:%02d.%09lld",typeq,timinfo->tm_year+1900,timinfo->tm_mon+1,timinfo->tm_mday,timinfo->tm_hour,timinfo->tm_min,timinfo->tm_sec,(x->j)%1000000000);
				}break;

		//month         i.e. 2000.01m
		case(-13):{	int timy=(x->i)/12+2000;
				int timm=(x->i)%12+1;
				printf("Month(%d) %04d.%02d",typeq,timy,timm);
				}break;

		//date          i.e. 2000.01.01
		case(-14):{	time_t timval=((x->i)+10957)*8.64e4;
				struct tm *timinfo;
				timinfo=localtime(&timval);
				printf("Date(%d) %04d.%02d.%02d",typeq,timinfo->tm_year+1900,timinfo->tm_mon+1,timinfo->tm_mday);
				}break;
			
		//datetime	i.e. 2012.01.01T12:12:12.000
		case(-15):{	time_t timval=((x->f)+10957)*8.64e4;
				struct tm *timinfo;
				timinfo=localtime(&timval);
				printf("Datetime(%d) %04d.%02d.%02dT%02d:%02d:%02d.%03lld",typeq,timinfo->tm_year+1900,timinfo->tm_mon+1,timinfo->tm_mday,timinfo->tm_hour,timinfo->tm_min,timinfo->tm_sec,(long long)(round((x->f)*8.64e7))%1000);
				}break;

		//timespan      i.e. 0D00:00:00.000000000
		case(-16):{	time_t timval=(x->j)/1000000000;
				struct tm *timinfo=localtime(&timval);
				printf("Timespan(%d) %dD%02d:%02d:%02d.%09lld",typeq,timinfo->tm_yday,timinfo->tm_hour-1,timinfo->tm_min,timinfo->tm_sec,(x->j)%1000000000);
				}break;	

		//minute        i.e. 00:00
		case(-17):{	time_t timval=(x->i)*60;
				struct tm *timinfo=localtime(&timval);
				printf("Minute(%d) %02d:%02d",typeq,timinfo->tm_hour-1,timinfo->tm_min);
				}break;

		//second        i.e. 00:00:00
		case(-18):{	time_t timval=(x->i);
				struct tm *timinfo=localtime(&timval);
				printf("Second(%d) %02d:%02d:%02d",typeq,timinfo->tm_hour-1,timinfo->tm_min,timinfo->tm_sec);
				}break;

		//time          i.e. 00:00:00.000
		case(-19):{	time_t timval=(x->i)/1000;
				struct tm *timinfo=localtime(&timval);
				printf("Time(%d) %02d:%02d:%02d.%03d",typeq,timinfo->tm_hour-1,timinfo->tm_min,timinfo->tm_sec,(x->i)%1000);
				}break;
		
		//default
		default:{	printf("cannot support %d type\n",x->t);
				return (K)0;
				}break;

	}

	return (K)0;

}
